//
//  ViewController.swift
//  exercicioUI - 2
//
//  Created by LAB ADA FOR on 25/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var meuLabel1: UILabel!
    @IBOutlet weak var meuLabel2: UILabel!
    @IBOutlet weak var meuLabel3: UILabel!
    
    @IBOutlet weak var meuTextField1: UITextField!
    @IBOutlet weak var meuTextField2: UITextField!
    @IBOutlet weak var meuTextField3: UITextField!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        meuTextField1.delegate = self
        //meuTextField1.becomeFirstResponder()
        
        meuTextField2.delegate = self
        //meuTextField2.becomeFirstResponder()
        
        meuTextField3.delegate = self
        //meuTextField3.becomeFirstResponder()
        meuTextField1.becomeFirstResponder()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if(textField == meuTextField1){
            meuTextField2.becomeFirstResponder()
        } else if(textField == meuTextField2){
            meuTextField3.becomeFirstResponder()
        } else if(textField == meuTextField3){
            meuTextField1.becomeFirstResponder()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

