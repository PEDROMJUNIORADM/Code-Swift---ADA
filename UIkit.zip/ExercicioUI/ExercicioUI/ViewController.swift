//
//  ViewController.swift
//  ExercicioUI
//
//  Created by LAB ADA FOR on 25/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var pessoa01 = Pessoa()
    
    @IBOutlet weak var mensagemNome: UILabel!
    @IBOutlet weak var mensagemIdade: UILabel!
    @IBOutlet weak var mensagemAltura: UILabel!
    
    
    @IBAction func exibir(_ sender: Any) {
        
        mensagemNome.text = pessoa01.nome
        mensagemIdade.text = pessoa01.idade
        mensagemAltura.text = pessoa01.altura
        
    }
    
    @IBAction func limpar(_ sender: Any) {
        
        mensagemNome.text = ""
        mensagemIdade.text = ""
        mensagemAltura.text = ""
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

