//
//  ViewController.swift
//  CustonCellsTableView
//
//  Created by Carlos Henrique Façanha Silva on 02/10/17.
//  Copyright © 2017 Carlos Henrique Façanha Silva. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, AddContactDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var contacts = [Contact]()
    
    var edit: Int = 1
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
     
        
        //self.tableView.isEditing = true
        
        
        
        tableView.dataSource = self
        tableView.delegate = self
        
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato0"), name: "Contato1", phone: "1111-1111"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato1"), name: "Contato2", phone: "2222-2222"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato2"), name: "Contato3", phone: "3333-3333"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato3"), name: "Contato4", phone: "4444-4444"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato4"), name: "Contato5", phone: "5555-5555"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato5"), name: "Contato6", phone: "6666-6666"))
        contacts.append(Contact(with:#imageLiteral(resourceName: "Contato6"), name: "Contato7", phone: "7777-7777"))
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func edit(_ sender: UIBarButtonItem) {
        
        if edit == 0{
            
            self.tableView.isEditing = false
            edit = 1
            //meuToolbar.title = "Cancel"
            
            
        }else if edit == 1{
            self.tableView.isEditing = true
            edit = 0
            //meuToolbar.title = "Cancel"
        }
        
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = self.contacts[sourceIndexPath.row]
        contacts.remove(at: sourceIndexPath.row)
        contacts.insert(movedObject, at: destinationIndexPath.row)
        
        // To check for correctness enable: self.tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete{
            
            self.contacts.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
            
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for:indexPath) as! CustomTableViewCell
        
        let contact = contacts[indexPath.row]
        
        cell.profileImageView.image = contact.profileImage
        cell.nameLabel.text = contact.name
        cell.phoneLabel.text = contact.phone
        
        return cell
    }
    

}

