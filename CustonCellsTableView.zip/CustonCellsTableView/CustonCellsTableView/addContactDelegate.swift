//
//  addContactDelegate.swift
//  CustonCellsTableView
//
//  Created by LAB ADA FOR on 04/10/17.
//  Copyright © 2017 Carlos Henrique Façanha Silva. All rights reserved.
//

import Foundation

protocol AddContactDelegate: class{
    
    func didCreateContact(_ contact: Contact)
    
}
