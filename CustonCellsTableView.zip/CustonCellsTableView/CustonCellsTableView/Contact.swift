//
//  Contact.swift
//  CustonCellsTableView
//
//  Created by Carlos Henrique Façanha Silva on 02/10/17.
//  Copyright © 2017 Carlos Henrique Façanha Silva. All rights reserved.
//

import Foundation
import UIKit

struct Contact
{
    var profileImage: UIImage
    var name: String
    var phone: String
    
    init(with profileImage: UIImage, name: String, phone: String)
    {
        self.profileImage = profileImage
        self.name = name
        self.phone = phone
    }
}
