//
//  CustomTableViewCell.swift
//  CustonCellsTableView
//
//  Created by Carlos Henrique Façanha Silva on 02/10/17.
//  Copyright © 2017 Carlos Henrique Façanha Silva. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell
{

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
   
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
        
        self.profileImageView.layer.masksToBounds = true
        
        self.profileImageView.layer.cornerRadius = profileImageView.frame.height/2
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
