//
//  ViewController.swift
//  PickerView - Exercicio 03
//
//  Created by LAB ADA FOR on 28/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    var dados = [ ["Fortaleza", "Rio de Janeiro","Salvador"], ["Praia de Iracema","Dragão do Mar", "Corcovado", "Pao de Acucar", "Maracana", "Pelourinho"] ]
    
    
    
    @IBOutlet weak var meuLabel: UILabel!
    @IBOutlet weak var pickerview: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        pickerview.delegate = self
        pickerview.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return dados.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dados[component].count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dados[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        let indiceCidade = pickerView.selectedRow(inComponent: 0)
        let indicePontoTuristico = pickerView.selectedRow(inComponent: 1)
        
        meuLabel.text = "Quando for á \([indiceCidade]) passe em \([indicePontoTuristico])"
        
        
    }


}

