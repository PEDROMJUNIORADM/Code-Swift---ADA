//
//  ViewController.swift
//  DatePicker
//
//  Created by LAB ADA FOR on 28/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var meuLabel1: UILabel!
    @IBOutlet weak var meuLabel2: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    
    @IBAction func onChange(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        let pickerDate = dateFormatter.string(from: sender.date)
        
        meuLabel1.text = pickerDate
        
        let nowDate = dateFormatter.string(from: Date())
        let rsp = sender.date > Date() ? "Maior" : "Menor"
        
        meuLabel2.text = "\(pickerDate) é \(rsp) do que \(nowDate)"
        
        //print("Estou Mudando!")
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        datePicker.datePickerMode = .date
        datePicker.locale = Locale(identifier: "pt_BR")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

