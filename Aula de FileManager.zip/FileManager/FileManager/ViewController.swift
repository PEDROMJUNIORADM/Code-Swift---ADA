//
//  ViewController.swift
//  FileManager
//
//  Created by LAB ADA FOR on 09/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var fileManager: FileManager = FileManager.default
    var docsDir: String?
    var dataFilePath: String?
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var errorMsg: UILabel!
    
    @IBAction func salvar(_ sender: UIButton) {
        
        
        do{
            try self.textView.text!.write(toFile: dataFilePath!, atomically: true, encoding: String.Encoding.utf8)
            self.errorMsg.text = "OK"
        
        } catch{ print(error)
        
        }
        
    }
   
    @IBAction func recuperar(_ sender: UIButton) {
        
        let file: FileHandle? = FileHandle(forReadingAtPath: dataFilePath!)
        
        if file == nil{
            print("File open Failde")
            self.errorMsg.text = "File open Failed"
        
        }else{
            
            let databuffer = file?.readDataToEndOfFile()
            
            file?.closeFile()
            
            // Coloca a string na view.
            self.textView.text = NSString(data: databuffer!, encoding: String.Encoding.utf8.rawValue)! as String
            self.errorMsg.text = "sdfdsfds"
            //self.textView.text = ""
        }
        
        
    }
    
    @IBAction func apagar(_ sender: UIButton) {
        
        do{
            try self.fileManager.removeItem(atPath: dataFilePath!)
            print("Remove Successful")
            self.errorMsg.text = "Remove Successful"
        
        }catch{
            
            print("Remove Failed with error: \(error)")
            self.errorMsg.text = "Remove failed with error: \(error)"
            
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.docsDir = self.getDocumentsDirectory()
        self.dataFilePath = String(format: "%@/datafile.txt", docsDir!
        )
        
        if fileManager.fileExists(atPath: dataFilePath!){
            //let dataBuffer = fileManager.contents(atPath: dataFilePath!)
            //let dataString = NSString(data: dataBuffer!, encoding: String.Encoding.utf8.rawValue)
            //self.textView.text = String(dataString!)
            
        }
        
        
    }
    
    /// Retorna o diretório de documentos do App.
    func getDocumentsDirectory() -> String{
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        let documentsDirectory = paths[0]
        
        return documentsDirectory
    }
    
    /// Caminho Construído Para Meu Diretório.
    override func viewDidAppear(_ animated: Bool) {
        print(self.getDocumentsDirectory())
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

