//
//  ViewController.swift
//  Exercico 02
//
//  Created by LAB ADA FOR on 09/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myTextView: UITextView!
    
    @IBAction func changerColor(_ sender: Any) {
        
        self.myLabel.text = NSString(format: "RED: %2.f", mySlider.value*255) as String
        
        let red = CGFloat(mySlider.value)
        
        view.backgroundColor = UIColor(red: red, green: 0.0, blue: 0.0, alpha: 1.0)
        
        self.savePlist()
        
    }
    
    func savePlist(){
        
        let colorList: NSArray = [mySlider.value]
        let save = colorList.write(toFile: self.path(), atomically: true)
        
        if save {
            print("Sucesso!")
        }else{
            print("Fail")
        }
        
    }
    
    func path() -> String {
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        return paths[0] + "/color.plist"
        
    }
    
    func plistToText() -> String{
        
    }
    
    func loadPlist(){
        let fileManager = FileManager.default
        let dataFilePath = self.path()
        
        if fileManager.fileExists(atPath: dataFilePath){
            print("Arquivo Lido Com Sucesso!")
            
            let colorList = NSArray(contentsOfFile: dataFilePath)
            
            if colorList != nil{
                
                self.mySlider.value = colorList![0] as! Float
                changerColor(NSNull.self)
                
            }else{
                print("Erro no Array")
            }
        
        }else{
            print("Arquivo ainda n disponivel")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    override func viewDidAppear(){
        
        print()
        
    }
    */

}

