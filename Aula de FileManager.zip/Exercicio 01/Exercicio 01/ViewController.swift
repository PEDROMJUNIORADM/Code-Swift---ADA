//
//  ViewController.swift
//  Exercicio 01
//
//  Created by LAB ADA FOR on 09/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var defaults = UserDefaults.standard
    let imageName = "minhaImagem.jpg"
    
    @IBOutlet weak var imageCima: UIImageView!
    @IBOutlet weak var imageBaixo: UIImageView!
    
    @IBAction func salvaImage(_ sender: UIButton) {
        
        // Baixa a Image.
        let imageData: Data! = self.getFile()
        
        // Obtem path do documents e adciona fileName
        let imagePath = self.documentsPathForFile(self.imageName)
        print(imagePath)
        /*
        do {
            try imageData.write(to: URL(fileURLWithPath: imagePath), options: .atomic)
        } catch {print(error)}
        */
        NSKeyedArchiver.archiveRootObject(imageData!, toFile: imagePath)
        
        self.imageCima.image = UIImage(data: imageData!)
        
    }
    
    
    @IBAction func recuperarImagem(_ sender: UIButton) {
        
        let path = self.documentsPathForFile(imageName)
        
        /*
        if let fileContent = try? Data(contentsOf: URL(fileURLWithPath: path)){
            self.imageBaixo.image = UIImage(data: fileContent)
        
        }else{
            print("No File To Read")
        }
        */
        
        if let fileContent2 = UIImage(data: NSKeyedUnarchiver.unarchiveObject(withFile: path) as! Data){
            
            self.imageBaixo.image = fileContent2
            
        }else{
            
            print("Fail to read file!")
            
        }
        
    }
    
    
    func documentsPathForFile(_ name: String) -> String{
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        return String(format: "%@/%@", paths[0], name)
        
    }
    
    //[3] download imagem local
    func getFile() -> Data? {
        
        let filePath = Bundle.main.path(forResource: "jangada", ofType: "jpg")
        
        return (try? Data(contentsOf: URL(fileURLWithPath: filePath!)))
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

