//
//  ViewController.swift
//  Toobar
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var soma: UILabel!
    @IBOutlet weak var compara: UILabel!
    
    @IBAction func resetValores(_ sender: UIBarButtonItem) {
        
        soma.text = "-----"
        compara.text = "Par Ou Ímpar: -----"
        
    }
    
    
    @IBAction func iniciarGame(_ sender: UIBarButtonItem) {
        
        let valor1: Int = 3
        let valor2: Int = 3
        
        if valor1 % valor2 == 0{
            soma.text = String(valor1 + valor2)
            soma.text = "Par Ou Ímpar: Par"
        }else{
            soma.text = String(valor1 + valor2)
            soma.text = "Par Ou Ímpar: Ímpar"
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

