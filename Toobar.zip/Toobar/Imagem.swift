//
//  Imagem.swift
//  Toobar
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//
