//
//  SecondViewController.swift
//  ExercicioTenso
//
//  Created by LAB ADA FOR on 17/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate {
    
    @IBOutlet weak var myTextFieldNome: UITextField!
    @IBOutlet weak var myTextFieldIdade: UITextField!
    @IBOutlet weak var myButtonFoto: UIButton!
    @IBOutlet weak var myButtonCancel: UIBarButtonItem!
    var pessoas: [String] = []
    
    @IBAction func uploadFoto(_ sender: UIButton) {
        
        let imagePicker = UIImagePickerController()
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        
        self.present(imagePicker, animated: true, completion: nil)
        
        imagePicker.delegate = self
        
    }
    
    /// Botao Cancel.
    @IBAction func voltar(_ sender: UIBarButtonItem) {
        
        self.dismiss(animated: true, completion: nil)
        
    }
    /// Botao Salve.
    @IBAction func salvar(_ sender: UIBarButtonItem) {
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        pessoas = ["Samuel","Herique","Ismael"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// Upload da Imagem.
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let image = info[UIImagePickerControllerEditedImage] as? UIImage
        
        myButtonFoto.setTitle(nil, for: .normal)
        myButtonFoto.setBackgroundImage(image, for: .normal)
        
        self.myButtonFoto.layer.masksToBounds = true
        self.myButtonFoto.layer.cornerRadius = myButtonFoto.frame.height/2
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
