//
//  ViewController.swift
//  ExercicioWebView
//
//  Created by LAB ADA FOR on 18/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var myTextField01: UITextField!
    @IBOutlet weak var myTextField02: UITextField!
    @IBOutlet weak var myTextField03: UITextField!
    
    var valor: String = ""
    var nome: String = ""
    var numero: String = ""
    
    @IBAction func calculaFatorial(_ sender: Any){
        
        valor = myTextField01.text!
        
        let url = URL(string: "https://www.ime.usp.br/~glauber/cgi-bin/BEPiD/fatorial?numero=\(String(valor))")
        let requisicao = URLRequest(url: url!)
        
        let sessao = URLSession.shared
        let tarefa = sessao.dataTask(with: requisicao, completionHandler:{(data, resposta, erro) -> Void in
        
            if erro == nil{
                let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print(resultado!)
            }
            else{
                print("Erro: \(erro!.localizedDescription)")
            }
        })

        tarefa.resume()
        
    }
    /// Metodo POST
    @IBAction func inserirContato(_ sender: Any) {
        
        nome = myTextField02.text!
        numero = myTextField03.text!
        
        let dados = "nome=\(String(nome))&fone=\(String(numero))"
        
        let urlencoded = dados.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        
        let url = URL(string: "https://www.ime.usp.br/~glauber/cgi-bin/BEPiD/insereContato")
        
        
        var requisicao = URLRequest(url: url!)
        requisicao.httpMethod = "POST"
        
        let data = urlencoded!.data(using: .utf8)
        requisicao.httpBody = data
        
        let sessao = URLSession.shared
        let tarefa = sessao.dataTask(with: requisicao, completionHandler:{(data, resposta, erro) -> Void in
            
            if erro == nil{
                let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print(resultado!)
            }
            else{
                print("Erro: \(erro!.localizedDescription)")
            }
        })
        
        tarefa.resume()
        
    }
    
    /*
     
     
     @IBAction func inserirContato(_ sender: Any) {
     
     nome = myTextField02.text!
     numero = myTextField03.text!
     
     let url = URL(string: "https://www.ime.usp.br/~glauber/cgi-bin/BEPiD/insereContato?nome=\(String(nome))&fone=\(String(numero))")
     let requisicao = URLRequest(url: url!)
     
     let sessao = URLSession.shared
     let tarefa = sessao.dataTask(with: requisicao, completionHandler:{(data, resposta, erro) -> Void in
     
     if erro == nil{
     let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
     print(resultado!)
     }
     else{
     print("Erro: \(erro!.localizedDescription)")
     }
     })
     
     tarefa.resume()
     
     }
     
    */
    
    @IBAction func envirCredencial(_ sender: Any) {
        
        let url = URL(string: "https://www.ime.usp.br/~glauber/BEPiD/")
        
        let requisicao = URLRequest(url : url!)
        
        let credencial = "BEPiD:foundation"
        let credencialData = credencial.data(using: .utf8)
        let credencialBase64 = credencialData!.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = ["Authorization" : "Basic \(credencialBase64)"]
        
        let sessao = URLSession(configuration: config)
        let tarefa = sessao.dataTask(with: requisicao, completionHandler:
        
            {(data, resposta, erro) -> Void in
                
                if erro == nil{
                    let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    print(resultado!)
                
                }else{
                    print("Erro: \(erro!.localizedDescription)")
                }
                
                
        })
        tarefa.resume()
    }
    
    
    
    @IBAction func verContato(_ sender: Any) {
        
        let url = URL(string: "https://www.ime.usp.br/~glauber/cgi-bin/BEPiD/verContatos")
        let requisicao = URLRequest(url: url!)
        
        let sessao = URLSession.shared
        let tarefa = sessao.dataTask(with: requisicao, completionHandler:{(data, resposta, erro) -> Void in
            
            if erro == nil{
                let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print(resultado!)
            }
            else{
                print("Erro: \(erro!.localizedDescription)")
            }
        })
        
        tarefa.resume()
        
    }
    
    @IBAction func gerarJson(_ sender: Any) {
        
        let lista = [["Nome" : "Rui", "Sexo" : "M"], ["Nome" : "Ana", "Sexo" : "F"]]
        
        do{
            let JSON = try JSONSerialization.data(withJSONObject: lista, options:[])
            
            let JSONdecodificado = try JSONSerialization.jsonObject(with: JSON, options: [])
            
            print(JSONdecodificado)
        
        }catch let erro as NSError{
            
            print("Erro: \(erro)")
            
        }
        
    }
    
    @IBAction func obterJson(_ sender: Any) {
        
        let url = URL(string: "https://www.ime.usp.br/~glauber/cgi-bin/BEPiD/JSON")
        let requisicao = URLRequest(url: url!)
        
        let sessao = URLSession.shared
        let tarefa = sessao.dataTask(with: requisicao, completionHandler:{(data, resposta, erro) -> Void in
            
            if erro == nil{
                
                let resultado = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print(resultado!)
            }
            else{
                print("Erro: \(erro!.localizedDescription)")
            }
        })
        
        tarefa.resume()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

