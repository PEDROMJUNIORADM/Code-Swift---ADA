//
//  ViewController.swift
//  WebView
//
//  Created by LAB ADA FOR on 18/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!
    @IBOutlet weak var myTextField: UIBarButtonItem!
    @IBOutlet weak var myButton: UIButton!
    
    
    @IBAction func voltar(_ sender: Any) {
        
        if myWebView.canGoBack {
            
            myWebView.goBack()
        
        }
        
        
    }
    
    @IBAction func avancar(_ sender: Any) {
        
        if myWebView.canGoForward {
            
            myWebView.goForward()
            
        }
    
    }
    
    @IBAction func carregarPag(_ sender: Any) {
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "http://www.ifce.edu.br")

        let requisicao = URLRequest(url: url!)
        
        myWebView.loadRequest(requisicao)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

