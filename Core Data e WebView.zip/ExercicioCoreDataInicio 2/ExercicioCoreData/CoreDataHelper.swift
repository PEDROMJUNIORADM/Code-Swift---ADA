//
//  CoreDataHelper.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral on 09/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import UIKit
import CoreData

enum CoreDataHelper {
    
    private static let persistentContainer = (UIApplication.shared.delegate as! AppDelegate).persistentContainer
    
    static func saveContext() {
        let context = persistentContainer.viewContext
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}
