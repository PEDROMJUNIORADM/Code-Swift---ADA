//
//  PersonProtocol.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral on 07/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import Foundation


protocol PersonProtocol : class {
    
    func didAddNewPerson(person:Person)
}
