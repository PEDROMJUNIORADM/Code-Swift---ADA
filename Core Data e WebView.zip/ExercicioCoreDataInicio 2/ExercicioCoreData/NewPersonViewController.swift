//
//  NewPersonViewController.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral on 07/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import UIKit

class NewPersonViewController: UIViewController {

    
}
