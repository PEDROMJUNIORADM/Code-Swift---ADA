//
//  ViewController.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral on 07/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import UIKit



class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, PersonProtocol {


    
    @IBOutlet weak var tableView: UITableView!
    
    
    var people: [Person]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        people = Person.listAll()
        
    }
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toNewPersonSegue" {
            guard let controller = segue.destination as? NewPersonViewController else {
                return
            }
            controller.personDelegate = self
        }
     }
 
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        print("\(indexPath.section) \(indexPath.row)")
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let p = people?[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "personCell", for: indexPath)
        cell.textLabel?.text = p?.name
        cell.detailTextLabel?.text = p?.phone
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let p = people?.remove(at: indexPath.row)
            p?.delete()
            CoreDataHelper.saveContext()
            tableView.reloadData()
        }
    }
    
    func didAddNewPerson(person: Person) {
        people?.append(person)
        tableView.reloadData()
    }
    
}

