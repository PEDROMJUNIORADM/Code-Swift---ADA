//
//  Person+CoreDataClass.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral de Oliveira on 08/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import UIKit
import CoreData


public class Person: NSManagedObject {
    
    public static let persistentContainer = (UIApplication.shared.delegate as! AppDelegate).persistentContainer
    
    
    class func listAll() -> [Person]? {
        let context = persistentContainer.viewContext
        var peopleArray: [Person]?
        do {
            try peopleArray = context.fetch(Person.fetchRequest()) as? [Person]
        } catch {
            print("Erro")
        }
        return peopleArray
    }
    
    class func create() -> Person {
        let entity = NSEntityDescription.entity(forEntityName: "Person", in: persistentContainer.viewContext)
        let p = Person(entity: entity!, insertInto: persistentContainer.viewContext)
        return p
    }
    
    func delete() {
        let context = Person.persistentContainer.viewContext
        context.delete(self)
    }

}
