//
//  Person+CoreDataProperties.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral de Oliveira on 08/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import Foundation
import CoreData


extension Person {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Person> {
        return NSFetchRequest<Person>(entityName: "Person")
    }

    @NSManaged public var name: String?
    @NSManaged public var phone: String?
    @NSManaged public var childNumber: Int16
    
    

}
