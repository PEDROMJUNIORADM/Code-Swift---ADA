//
//  ViewController.swift
//  UIImage
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var myimage: UIImageView!
    
    
    @IBAction func mybutton(_ sender: UIButton) {
        myimage.self.image = UIImage(named: "ifce-blog-2.jpg")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

