//
//  ViewController.swift
//  TableView - 02
//
//  Created by LAB ADA FOR on 02/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class DynamicCellsViewController: UIViewController, UITableViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        }else{
            return person.addresses.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "basicCell", for: indexPath)
            
            if indexPath.row  == 0{
                
                cell.textLabel?.text = person.nome
                
            }else{
                cell.textLabel?.text = "\(person.age)"
            }
            
            return cell
        
        }else{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "rightDEtailCell", for: <#T##IndexPath#>)
            
        }
        
    }

}

