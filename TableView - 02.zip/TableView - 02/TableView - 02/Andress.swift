//
//  Andress.swift
//  TableView - 02
//
//  Created by LAB ADA FOR on 02/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import Foundation

struct andresses{
    
    var street: String
    var number: Int
    
}
