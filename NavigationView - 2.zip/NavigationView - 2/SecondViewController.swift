//
//  SecondViewController.swift
//  NavigationView - 2
//
//  Created by LAB ADA FOR on 04/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class SecondViewController: UITableViewCell {
    
    
    @IBAction func closer(_ sender: UIButton) {
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
