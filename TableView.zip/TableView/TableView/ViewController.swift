//
//  ViewController.swift
//  TableView
//
//  Created by LAB ADA FOR on 02/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let selectedCell = tableView.cellForRow(at: indexPath) else {return}
        guard let colorName = selectedCell.textLabel?.text else {return}
        
        tableView.deselectRow(at: indexPath, animated: true)
        print("Selecionou Cor \(colorName)")
        
    }
    
    private func showAlertForColorSelection(with colorName: String){
        
        let alert = UIAlertController(title: "Selecao de Cores", message: "Voce selecionou a cor \(colorName)", preferredStyle: .alert)
        
        
        dismissAction = UIAlertAction(tittle: "Ok", style: .default, handle: nil)
        
        alert.addAction(dismissAction)
        self.present(alert, animated: true, completion: nil)
        
    }
 
}

