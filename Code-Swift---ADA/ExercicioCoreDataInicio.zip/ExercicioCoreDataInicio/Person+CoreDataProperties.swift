//
//  Person+CoreDataProperties.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral de Oliveira on 08/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import Foundation
import CoreData


extension Person {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Person> {
        return NSFetchRequest<Person>(entityName: "Person")
    }

    @NSManaged public var name: String?
    @NSManaged public var phone: String?
    @NSManaged public var childNumber: Int16
    
    class func find(byName name: String) -> Person?{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        let predicate = NSPredicate(format: "name == %@", name)
        request.predicate = predicate
        
        var people : [Person] = []
        
        do{
            
            people = try context.fetch(request)
            
        }catch{
            return nil
        }
        
        if people.count == 0{
            return nil
        }
        
        return people[0]
    }
    
    class func find(byPhone phone: String) -> Person?{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        let predicate = NSPredicate(format: "phone == %@", phone)
        request.predicate = predicate
        
        var people : [Person] = []
        
        do{
            people = try context.fetch(request)
        }catch{
            return nil
        }
        
        if people.count == 0{
            return nil
        }
        
        return people[0]
        
    }
    
    /*
    class func find(byName name: String, andPhone phone: String) -> Person?{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        let predicate1 = NSPredicate(format: "name == %@", name)
        let predicate2 = NSPredicate(format: "phone == %@", phone)
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [predicate1,predicate2])
        
        request.predicate = compoundPredicate
        
        var people : [Person] = []
        
        do{
            people = try context.fetch(request)
        }catch{
            return nil
        }
        
        if people.count == 0{
            return nil
        }
        
        return people[0]
        
    }
    */
    /*
    class func listAll(beginsWith name: String) -> [Person]{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        
        let predicate = NSPredicate(format: "name BEGINSWITH[cd] %@", name)
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        
        request.predicate = predicate
        request.sortDescriptors = [sortDescriptor]
        
        var people : [Person] = []
        
        do{
            people = try context.fetch(request)
        }catch{
            return []
        }
        
        return people
        
    }
    */
    
    //LISTA OS CONTATOS PELA SUBSTRING(IDEAL)
    class func listAll(contains name: String) -> [Person]{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        let predicate = NSPredicate(format: "name contains[cd] %@", name)
        
        request.predicate = predicate
        
        var people : [Person] = []
        
        do{
            people = try context.fetch(request)
        }catch{
            return []
        }
        
        return people
        
    }
 

    /*
    class func listAll(withChildNumber initialValue: Int16, finalValue: Int16) -> [Person]{
        
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<Person>(entityName: "Person")
        let predicate = NSPredicate(format: "childNumber >= %i AND childNumber <= %i", initialValue, finalValue)
        
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        
        request.predicate = predicate
        request.sortDescriptors = [sortDescriptor]
        
        var people : [Person] = []
        do{
            people = try context.fetch(request)
            
        }catch{
            return []
        }
        
        return people
        
    }
    */
    
}
