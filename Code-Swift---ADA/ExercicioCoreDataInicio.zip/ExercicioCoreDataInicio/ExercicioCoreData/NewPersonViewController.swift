//
//  NewPersonViewController.swift
//  ExercicioCoreData
//
//  Created by Davi Cabral on 07/06/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import UIKit

class NewPersonViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var phoneTextField: UITextField!

    @IBOutlet weak var childNumber: UITextField!
    
    
    weak var personDelegate: PersonProtocol?
    
    
    @IBAction func didTapAdicionarButton(_ sender: Any) {
        
        let p = Person.create()
        p.name = nameTextField.text
        p.phone = phoneTextField.text
        
        if let number = Int16(childNumber.text!){            p.childNumber = number
        } else {
            p.childNumber = 0
        }
        
        print(p.childNumber)
        
        CoreDataHelper.saveContext()
        personDelegate?.didAddNewPerson(person: p)
        navigationController?.popViewController(animated: true)
    }

}
