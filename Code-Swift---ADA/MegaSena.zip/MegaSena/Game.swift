//
//  Game.swift
//  MegaSena
//
//  Created by LAB ADA FOR on 27/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import Foundation

class Game{
    
    
    
}
