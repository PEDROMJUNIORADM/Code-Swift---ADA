//
//  ViewController.swift
//  MegaSena
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var meuLabel01: UILabel! // Label "MEGA SENA"
    
    @IBOutlet weak var meuLabel02: UILabel!
    @IBOutlet weak var meuLabel03: UILabel!
    @IBOutlet weak var meuLabel04: UILabel!
    @IBOutlet weak var meuLabel05: UILabel!
    @IBOutlet weak var meuLabel06: UILabel!
    @IBOutlet weak var meuLabel07: UILabel!
    
    @IBAction func buttonLimpar(_ sender: UIButton) {
        
        meuLabel02.text = "?"
        meuLabel03.text = "?"
        meuLabel04.text = "?"
        meuLabel05.text = "?"
        meuLabel06.text = "?"
        meuLabel07.text = "?"
        
    }
    
    
    @IBAction func buttonJogar(_ sender: UIButton) {
        
        meuLabel02.text = String(arc4random_uniform(60)+1)
        meuLabel03.text = String(arc4random_uniform(60)+1)
        meuLabel04.text = String(arc4random_uniform(60)+1)
        meuLabel05.text = String(arc4random_uniform(60)+1)
        meuLabel06.text = String(arc4random_uniform(60)+1)
        meuLabel07.text = String(arc4random_uniform(60)+1)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

