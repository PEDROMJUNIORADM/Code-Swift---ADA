//
//  ViewController.swift
//  Exercicio - 09
//
//  Created by LAB ADA FOR on 27/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var segControl: UISegmentedControl!
    
    @IBAction func meuSegmentedControl(_ sender: UISegmentedControl) {
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

