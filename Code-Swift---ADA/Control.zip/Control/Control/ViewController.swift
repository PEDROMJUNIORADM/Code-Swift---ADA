//
//  ViewController.swift
//  Control
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var SegCtrl: UISegmentedControl!
    
    @IBOutlet weak var UpLabel: UILabel!
    @IBOutlet weak var DownLabel: UILabel!
    
    
    @IBAction func IndexChanged(_ sender: UISegmentedControl) {
        
        let indx = SegCtrl.selectedSegmentIndex
        UpLabel.text = String(indx-1)
        DownLabel.text = sender.titleForSegment(at: indx)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

