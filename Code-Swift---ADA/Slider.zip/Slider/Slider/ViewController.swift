//
//  ViewController.swift
//  Slider
//
//  Created by LAB ADA FOR on 26/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var meuLabel01: UILabel! // Minha String "VALOR"
    @IBOutlet weak var meuLabel02: UILabel! // Recebe a intensidade dos Slides
    
    // A intensidade dos meus slides sao passados para meu label02.
    @IBAction func meuSlider01(_ sender: UISlider) { // Meu Slider 01
        
        let valor = sender.value
        meuLabel02.text = String(valor) // Cast
        
    }
    
    @IBAction func meuSlider02(_ sender: UISlider) { // Meu Slider 02
        
        let valor = sender.value
        meuLabel02.text = String(valor) // Cast
    
    }
   
    @IBAction func meuSlider03(_ sender: UISlider) { // Meu Slider 03
        
        let valor = sender.value
        meuLabel02.text = String(valor) // Cast
        
    }
    
    // Mudo a intesidade da cor dos meus Sliders.
    @IBAction func mudarCorSlider01(_ sender: UISlider) {
        
        view.backgroundColor = UIColor(red: CGFloat(sender.value), green: 0.0, blue: 0.0, alpha: 1.0)
    }
    
    @IBAction func mudarCorSlider02(_ sender: UISlider) {
        
        view.backgroundColor = UIColor(red: 0.0, green: CGFloat(sender.value), blue: 0.0, alpha: 1.0)
        
    }
    
    @IBAction func mudarCorSlider03(_ sender: UISlider) {
        
        view.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: CGFloat(sender.value), alpha: 1.0)
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

