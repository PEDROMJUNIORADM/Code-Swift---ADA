//
//  ViewController.swift
//  Exercicio - 06
//
//  Created by LAB ADA FOR on 27/09/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var meuLabel01: UILabel!
    @IBOutlet weak var meuLabel02: UILabel!
    @IBOutlet weak var meuLabel03: UILabel!
    
    @IBOutlet weak var meuTextField01: UITextField!
    @IBOutlet weak var meuTextField02: UITextField!
    @IBOutlet weak var meuTextField03: UITextField!
    
    
    @IBAction func meuSlider01(_ sender: UISlider) {
        //let valor = sender.value
        //meuTextField01.text = String(valor)
        // Assim, n vai aparecer os valores dentro do textfield.
    }
    
    @IBAction func meuSlider02(_ sender: UISlider) {
        //let valor = sender.value
        //meuTextField02.text = String(valor)
        // Assim, n vai aparecer os valores dentro do textfield.
    }
    
    @IBAction func meuSlider03(_ sender: UISlider) {
        //let valor = sender.value
        //meuTextField03.text = String(valor)
        // Assim, n vai aparecer os valores dentro do textfield.
    }
    
    @IBAction func mudarCorSlider01(_ sender: UISlider) {
        meuTextField01.backgroundColor = UIColor(red: CGFloat(sender.value), green: 0.0, blue: 0.0, alpha: 1.0)
    }
    
    @IBAction func mudarCorSlider02(_ sender: UISlider) {
        meuTextField02.backgroundColor = UIColor(red: 0.0, green: CGFloat(sender.value), blue: 0.0, alpha: 1.0)
    }
    
    @IBAction func mudarCorSlider03(_ sender: UISlider) {
        meuTextField03.backgroundColor = UIColor(red: 0.0, green: 0.0,
                                       blue: CGFloat(sender.value), alpha: 1.0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

