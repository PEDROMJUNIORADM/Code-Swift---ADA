//
//  ViewController.swift
//  Calendario
//
//  Created by LAB ADA FOR on 03/10/17.
//  Copyright © 2017 LAB ADA FOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    typealias Dados = (nome: String, date: String, priority: String)
    var arrayEventos = [Dados]()
    
    @IBAction func addEvento(_ sender: UIBarButtonItem) {
        
        showAlert()
        
    }
    
    func showAlert(){
        
        //1. Create the alert controller.
        let alert = UIAlertController(title: "Eventos", message: "Adcionar Evento", preferredStyle: .alert)
        
        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.placeholder = "Nome do Evento"
        }
        
        alert.addTextField{ (textField) in
            textField.placeholder = "DD/MM/YYYY"
        }
        
        alert.addTextField{ (textField) in
            textField.placeholder = "Prioridade"
        }
        
        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            
            let textField1 = alert?.textFields?[0].text // Force unwrapping because we know it exists.
            let textField2 = alert?.textFields?[1].text
            let textField3 = alert?.textFields?[2].text
            //print("Text field: \(String(describing: textField?.text))")
            
            arrayEventos.append(nome: textField1, date: textField2, priority: textField3)
            
            
        }))
        
        
        
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)

        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

